// Assets/Scripts/Player/WraithVictimLock.cs
using System.Collections;
using UnityEngine;

[DisallowMultipleComponent]
public class WraithVictimLock : MonoBehaviour
{
    [Header("Auto References")]
    public CharacterController characterController;
    public MonoBehaviour playerControllerBehaviour;

    [Header("Disable During Capture")]
    [Tooltip("ProCamera2D, CinemachineBrain, ���콺��, ī�޶� ���� ��ũ��Ʈ ��")]
    public Behaviour[] cameraDriversToDisable;

    [Tooltip("�÷��̾� �Է�(���콺 ��/ī�޶� ȸ�� ��) ��ũ��Ʈ��")]
    public Behaviour[] playerInputToDisable;

    [Header("Captured State")]
    public bool isCaptured;
    public Transform holdPoint;
    public Transform wraithFacePoint;

    [Header("Hold Offset")]
    public Vector3 extraHoldOffset = Vector3.zero;

    [Header("Victim Rotation")]
    public bool rotateVictimToLookAtWraith = true;

    [Header("Camera Override")]
    public bool controlMainCamera = true;
    public bool hardLockCamera = true;  // ��鸮�� true ����
    public float cameraLerpSpeed = 10f;

    public float faceDistanceFar = 0.9f;
    public float faceDistanceNear = 0.25f;
    public float fovFar = 55f;
    public float fovNear = 28f;

    public float faceUpOffset = 0.05f;
    public float faceSideOffset = 0.0f;

    [Range(0f, 1f)] public float zoom01;

    [Header("Temporary Camera")]
    [Tooltip("true�� Capture �� �ӽ� ī�޶� �����ؼ� �װɷ� ��/����. Release �� ���� �� ���� ī�޶� ����.")]
    public bool useTemporaryCamera = true;

    [Tooltip("�ӽ� ī�޶� ������Ʈ �̸�")]
    public string tempCameraName = "WraithTempCamera";

    [Header("Restore")]
    [Tooltip("Release �� ī�޶� ����̹��� '���� ������'�� �Ѽ� ���� �浹�� ����")]
    public bool enableDriversNextFrame = true;

    private bool cachedPcEnabled;
    private bool cachedCcEnabled;

    // pivot->mid offset
    private float pivotToMidY = 0.9f;

    // Original camera cache
    private Camera originalCam;
    private Vector3 camPos0;
    private Quaternion camRot0;
    private float camFov0;
    private bool originalCameraEnabled;
    private string originalTag;

    // Temporary camera
    private GameObject tempCamGO;
    private Camera tempCam;

    private bool[] camDriversEnabled0;
    private bool[] playerInputsEnabled0;

    private Coroutine restoreCo;

    void Awake()
    {
        if (characterController == null) characterController = GetComponent<CharacterController>();

        if (playerControllerBehaviour == null)
        {
            var pc = GetComponent<PlayerController>();
            if (pc != null) playerControllerBehaviour = pc;
        }
    }

    void LateUpdate()
    {
        if (!isCaptured) return;

        // Victim follow hand (grab middle, not feet)
        if (holdPoint != null)
            transform.position = holdPoint.position - Vector3.up * pivotToMidY + extraHoldOffset;

        // Victim faces wraith (optional)
        if (rotateVictimToLookAtWraith && wraithFacePoint != null)
        {
            Vector3 to = wraithFacePoint.position - transform.position;
            to.y = 0f;
            if (to.sqrMagnitude > 0.0004f)
                transform.rotation = Quaternion.LookRotation(to.normalized, Vector3.up);
        }

        // Camera looks at wraith face (temp cam preferred)
        Camera activeCam = (useTemporaryCamera && tempCam != null) ? tempCam : originalCam;
        if (!controlMainCamera || activeCam == null || wraithFacePoint == null) return;

        float dist = Mathf.Lerp(faceDistanceFar, faceDistanceNear, zoom01);
        float fov = Mathf.Lerp(fovFar, fovNear, zoom01);

        Vector3 facePos = wraithFacePoint.position;
        Vector3 desiredPos =
            facePos + wraithFacePoint.forward * dist
            + Vector3.up * faceUpOffset
            + wraithFacePoint.right * faceSideOffset;

        Vector3 lookDir = facePos - desiredPos;
        Quaternion desiredRot = activeCam.transform.rotation;
        if (lookDir.sqrMagnitude > 0.0004f)
            desiredRot = Quaternion.LookRotation(lookDir.normalized, Vector3.up);

        if (hardLockCamera)
        {
            activeCam.transform.SetPositionAndRotation(desiredPos, desiredRot);
            activeCam.fieldOfView = fov;
        }
        else
        {
            activeCam.transform.position = Vector3.Lerp(activeCam.transform.position, desiredPos, Time.deltaTime * cameraLerpSpeed);
            activeCam.transform.rotation = Quaternion.Slerp(activeCam.transform.rotation, desiredRot, Time.deltaTime * cameraLerpSpeed);
            activeCam.fieldOfView = Mathf.Lerp(activeCam.fieldOfView, fov, Time.deltaTime * cameraLerpSpeed);
        }
    }

    public void Capture(Transform hold, Transform face)
    {
        if (isCaptured) return;

        if (restoreCo != null)
        {
            StopCoroutine(restoreCo);
            restoreCo = null;
        }

        holdPoint = hold;
        wraithFacePoint = face;
        isCaptured = true;

        pivotToMidY = ComputePivotToMidY();
        zoom01 = 0f;

        // Disable player movement / controller
        if (playerControllerBehaviour != null)
        {
            cachedPcEnabled = playerControllerBehaviour.enabled;
            playerControllerBehaviour.enabled = false;
        }

        if (characterController != null)
        {
            cachedCcEnabled = characterController.enabled;
            characterController.enabled = false;
        }

        // Cache original camera state (EVERY capture)
        if (controlMainCamera)
        {
            originalCam = Camera.main;
            if (originalCam != null)
            {
                camPos0 = originalCam.transform.position;
                camRot0 = originalCam.transform.rotation;
                camFov0 = originalCam.fieldOfView;

                originalCameraEnabled = originalCam.enabled;
                originalTag = originalCam.gameObject.tag;
            }
        }

        // Disable camera drivers & inputs so mouse can't move camera
        DisableBehaviours(cameraDriversToDisable, ref camDriversEnabled0);
        DisableBehaviours(playerInputToDisable, ref playerInputsEnabled0);

        // Create temp camera and switch rendering to it
        if (useTemporaryCamera && originalCam != null)
        {
            // Disable original camera rendering (keep object alive)
            originalCam.enabled = false;

            // Swap tags to ensure Camera.main points to temp while captured
            originalCam.gameObject.tag = "Untagged";

            tempCamGO = new GameObject(tempCameraName);
            tempCamGO.transform.position = camPos0;
            tempCamGO.transform.rotation = camRot0;
            tempCamGO.tag = "MainCamera";

            tempCam = tempCamGO.AddComponent<Camera>();

            // Copy important camera settings
            tempCam.clearFlags = originalCam.clearFlags;
            tempCam.backgroundColor = originalCam.backgroundColor;
            tempCam.cullingMask = originalCam.cullingMask;
            tempCam.orthographic = originalCam.orthographic;
            tempCam.orthographicSize = originalCam.orthographicSize;
            tempCam.nearClipPlane = originalCam.nearClipPlane;
            tempCam.farClipPlane = originalCam.farClipPlane;
            tempCam.allowHDR = originalCam.allowHDR;
            tempCam.allowMSAA = originalCam.allowMSAA;
            tempCam.depth = originalCam.depth + 10f; // ensure it renders on top
            tempCam.fieldOfView = camFov0;
        }
    }

    public void Release()
    {
        if (!isCaptured) return;

        isCaptured = false;

        // Restore player control
        if (playerControllerBehaviour != null)
            playerControllerBehaviour.enabled = cachedPcEnabled;

        if (characterController != null)
            characterController.enabled = cachedCcEnabled;

        // Destroy temp camera and restore original camera
        if (useTemporaryCamera && tempCamGO != null)
        {
            Destroy(tempCamGO);
            tempCamGO = null;
            tempCam = null;
        }

        if (controlMainCamera && originalCam != null)
        {
            // Restore tag
            originalCam.gameObject.tag = string.IsNullOrEmpty(originalTag) ? "MainCamera" : originalTag;

            // Restore original camera transform/FOV
            originalCam.transform.SetPositionAndRotation(camPos0, camRot0);
            originalCam.fieldOfView = camFov0;

            // Re-enable original camera rendering
            originalCam.enabled = originalCameraEnabled;
        }

        // Re-enable drivers (same frame or next frame)
        if (enableDriversNextFrame)
        {
            restoreCo = StartCoroutine(EnableDriversNextFrame());
        }
        else
        {
            RestoreBehaviours(cameraDriversToDisable, camDriversEnabled0);
            RestoreBehaviours(playerInputToDisable, playerInputsEnabled0);
        }

        // cleanup
        holdPoint = null;
        wraithFacePoint = null;
        zoom01 = 0f;
    }

    public void SetCinematicZoom01(float t) => zoom01 = Mathf.Clamp01(t);

    private IEnumerator EnableDriversNextFrame()
    {
        yield return null;

        RestoreBehaviours(cameraDriversToDisable, camDriversEnabled0);
        RestoreBehaviours(playerInputToDisable, playerInputsEnabled0);

        restoreCo = null;
    }

    private void DisableBehaviours(Behaviour[] list, ref bool[] cache)
    {
        if (list == null || list.Length == 0) { cache = null; return; }

        cache = new bool[list.Length];
        for (int i = 0; i < list.Length; i++)
        {
            if (list[i] == null) continue;
            cache[i] = list[i].enabled;
            list[i].enabled = false;
        }
    }

    private void RestoreBehaviours(Behaviour[] list, bool[] cache)
    {
        if (list == null || cache == null) return;

        for (int i = 0; i < list.Length && i < cache.Length; i++)
        {
            if (list[i] == null) continue;
            list[i].enabled = cache[i];
        }
    }

    private float ComputePivotToMidY()
    {
        if (characterController != null)
        {
            float y = Mathf.Abs(characterController.center.y);
            if (y > 0.05f) return y;
            return Mathf.Max(0.2f, characterController.height * 0.5f);
        }

        Collider col = GetComponent<Collider>();
        if (col != null)
        {
            float midY = col.bounds.center.y;
            return Mathf.Max(0.2f, midY - transform.position.y);
        }

        Renderer r = GetComponentInChildren<Renderer>();
        if (r != null)
        {
            float midY = r.bounds.center.y;
            return Mathf.Max(0.2f, midY - transform.position.y);
        }

        return 0.9f;
    }
}
