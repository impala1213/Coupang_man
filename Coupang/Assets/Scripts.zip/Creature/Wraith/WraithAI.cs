﻿// Assets/Scripts/Creature/WraithAI.cs
using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
[RequireComponent(typeof(CharacterController))]
[RequireComponent(typeof(Health))]
public class WraithAI : MonoBehaviour
{
    private enum State { Patrol, Roar, Chase, GrabAnim, Attack, Dead }

    [Header("Refs")]
    public Animator animator;
    public CharacterController controller;
    public Health health;

    [Header("Target Rules")]
    public int minKillsToTarget = 3;
    public bool allowProvokedTargets = true;

    [Header("Detection")]
    public float detectionRadius = 25f;
    [Range(1f, 360f)] public float viewAngle = 140f;
    public bool requireLineOfSight = true;
    public LayerMask occlusionMask = ~0;
    public float eyeHeight = 1.6f;

    [Header("Movement")]
    public float walkSpeed = 2f;
    public float runSpeed = 7f;
    public float turnSpeed = 10f;
    public float gravity = -19.62f;

    [Header("Patrol")]
    public float wanderRadius = 10f;
    public float wanderPointTolerance = 1.2f;
    public float idleTimeMin = 0.8f;
    public float idleTimeMax = 2.0f;

    [Header("Roar -> Chase")]
    public string roarTriggerParam = "Roar";
    public float roarDuration = 1.0f;

    [Header("Grab -> Attack")]
    public float grabStartRange = 2.8f;
    public float grabConfirmRange = 3.2f;
    public float grabFallbackTime = 0.7f;

    [Header("Attack Hold (time-based)")]
    [Tooltip("Attack 마지막 프레임 도달 후 이 시간만큼 고정 유지 후 데미지")]
    public float attackHoldTime = 1.5f;

    [Tooltip("Attack에서 줌이 0->1로 올라가는 시간")]
    public float attackZoomDuration = 1.5f;

    [Tooltip("Attack 클립 길이(초). Tag 감지가 안되면 이걸로 마지막프레임 타이밍을 잡음.")]
    public float attackClipLength = 1.0f;

    [Tooltip("이 시간 이상(AttackClip+Hold+여유) 지나면 강제 Release (버그 방지)")]
    public float attackMaxTotalTime = 4.0f;

    public int executeDamage = 999999;

    [Header("Animation")]
    public string speedParam = "Speed";
    public float speedDamp = 12f;
    public string isDeadParam = "IsDead";
    public string grabTriggerParam = "Grab";
    public string attackTriggerParam = "Attack";
    public string grabStateTag = "Grab";
    public string attackStateTag = "Attack";

    [Header("Victim Hold / Face")]
    public Transform victimHoldPoint;
    public Transform wraithFacePoint;

    [Header("Scan")]
    public float scanInterval = 0.4f;

    [Header("Debug")]
    public bool debugLogs;

    private State state = State.Patrol;

    private readonly HashSet<Transform> provokedTargets = new HashSet<Transform>();
    private Transform lockedTarget;

    private Vector3 homePos;
    private Vector3? patrolTarget;
    private float idleTimer;

    private float roarTimer;
    private float verticalVelocity;

    private Vector3 lastPos;
    private float smoothedSpeed;

    private float scanTimer;

    private float grabTimer;

    private bool attackFrozen;
    private float attackHoldTimer;
    private float attackStartTime;

    private WraithVictimLock victimLock;

    // Rotation lock (prevents spinning feedback)
    private bool lockFacingActive;
    private Quaternion lockedFacingRotation;

    void Awake()
    {
        if (controller == null) controller = GetComponent<CharacterController>();
        if (health == null) health = GetComponent<Health>();

        if (animator == null)
        {
            animator = GetComponent<Animator>();
            if (animator == null) animator = GetComponentInChildren<Animator>();
        }

        if (animator != null) animator.applyRootMotion = false;

        // CreatureChase가 붙어있으면 wraith는 자체 로직 사용
        var chase = GetComponent<CreatureChase>();
        if (chase != null && chase.enabled) chase.enabled = false;

        homePos = transform.position;
        lastPos = transform.position;

        health.OnDeath += OnDeath;
    }

    void Update()
    {
        if (health.IsDead())
            state = State.Dead;

        // target dead clear
        if (lockedTarget != null)
        {
            var th = lockedTarget.GetComponentInChildren<Health>();
            if (th != null && th.IsDead())
                lockedTarget = null;

            if (lockedTarget == null)
                ReleaseVictimAndCamera();
        }

        scanTimer -= Time.deltaTime;
        if (scanTimer <= 0f)
        {
            scanTimer = Mathf.Max(0.05f, scanInterval);
            TryAcquireTargetIfNeeded();
        }

        switch (state)
        {
            case State.Patrol: TickPatrol(); break;
            case State.Roar: TickRoar(); break;
            case State.Chase: TickChase(); break;
            case State.GrabAnim: TickGrabAnim(); break;
            case State.Attack: TickAttack(); break;
            case State.Dead: TickDead(); break;
        }

        ApplyGravity();
        UpdateAnimatorSpeed();
        lastPos = transform.position;
    }

    public void NotifyDamagedBy(Transform attacker)
    {
        if (!allowProvokedTargets) return;
        if (state == State.Dead) return;
        if (attacker == null) return;

        Transform root = attacker.root;
        provokedTargets.Add(root);

        if (lockedTarget == null)
        {
            lockedTarget = root;
            EnterRoar();
        }
    }

    private void TryAcquireTargetIfNeeded()
    {
        if (lockedTarget != null) return;

        Transform best = FindBestValidDetectableTargetRoot();
        if (best != null)
        {
            lockedTarget = best;
            EnterRoar();
        }
    }

    // ★ 핵심: 무조건 "플레이어 루트"를 리턴
    private Transform FindBestValidDetectableTargetRoot()
    {
        Transform best = null;
        float bestDist = float.MaxValue;

        var marks = FindObjectsOfType<WraithVengeanceMark>();
        for (int i = 0; i < marks.Length; i++)
        {
            var m = marks[i];
            if (m == null) continue;
            if (m.creatureKills < minKillsToTarget) continue;

            Transform root = m.transform.root;
            if (!IsDetectable(root)) continue;

            float d = HorizontalDistance(transform.position, root.position);
            if (d < bestDist)
            {
                bestDist = d;
                best = root;
            }
        }

        if (allowProvokedTargets)
        {
            foreach (var t in provokedTargets)
            {
                if (t == null) continue;
                if (!IsDetectable(t)) continue;

                float d = HorizontalDistance(transform.position, t.position);
                if (d < bestDist)
                {
                    bestDist = d;
                    best = t;
                }
            }
        }

        return best;
    }

    private bool IsTargetValid(Transform targetRoot)
    {
        if (targetRoot == null) return false;

        if (allowProvokedTargets && provokedTargets.Contains(targetRoot))
            return true;

        // mark가 자식에 있어도 찾게
        var mark = targetRoot.GetComponentInChildren<WraithVengeanceMark>();
        if (mark == null) return false;

        return mark.creatureKills >= minKillsToTarget;
    }

    private bool IsDetectable(Transform targetRoot)
    {
        if (!IsTargetValid(targetRoot)) return false;

        Vector3 to = targetRoot.position - transform.position;
        float dist = new Vector3(to.x, 0f, to.z).magnitude;
        if (dist > detectionRadius) return false;

        to.y = 0f;
        if (to.sqrMagnitude > 0.0001f)
        {
            float ang = Vector3.Angle(transform.forward, to.normalized);
            if (ang > viewAngle * 0.5f) return false;
        }

        if (!requireLineOfSight) return true;

        Vector3 origin = transform.position + Vector3.up * eyeHeight;
        Vector3 p0 = targetRoot.position + Vector3.up * 0.6f;
        Vector3 p1 = targetRoot.position + Vector3.up * 1.2f;
        Vector3 p2 = targetRoot.position + Vector3.up * 1.8f;

        return HasLine(origin, p0, targetRoot) || HasLine(origin, p1, targetRoot) || HasLine(origin, p2, targetRoot);
    }

    private bool HasLine(Vector3 origin, Vector3 targetPoint, Transform targetRoot)
    {
        Vector3 dir = targetPoint - origin;
        float dist = dir.magnitude;
        if (dist <= 0.001f) return true;
        dir /= dist;

        if (Physics.Raycast(origin, dir, out RaycastHit hit, dist, occlusionMask, QueryTriggerInteraction.Ignore))
            return hit.collider != null && hit.collider.transform.root == targetRoot;

        return true;
    }

    private void TickPatrol()
    {
        ReleaseVictimAndCamera();
        lockFacingActive = false;

        if (idleTimer <= 0f && !patrolTarget.HasValue)
            idleTimer = Random.Range(idleTimeMin, idleTimeMax);

        if (idleTimer > 0f)
        {
            idleTimer -= Time.deltaTime;
            return;
        }

        if (!patrolTarget.HasValue)
        {
            Vector2 r = Random.insideUnitCircle * wanderRadius;
            patrolTarget = homePos + new Vector3(r.x, 0f, r.y);
        }

        MoveTowards(patrolTarget.Value, walkSpeed);

        if (HorizontalDistance(transform.position, patrolTarget.Value) <= wanderPointTolerance)
        {
            patrolTarget = null;
            idleTimer = Random.Range(idleTimeMin, idleTimeMax);
        }
    }

    private void EnterRoar()
    {
        if (state == State.Dead) return;
        if (lockedTarget == null) return;
        if (!IsTargetValid(lockedTarget))
        {
            lockedTarget = null;
            state = State.Patrol;
            return;
        }

        if (state == State.GrabAnim || state == State.Attack) return;

        state = State.Roar;
        roarTimer = Mathf.Max(0.01f, roarDuration);

        FaceTowards(lockedTarget.position);

        if (animator != null && !string.IsNullOrEmpty(roarTriggerParam))
        {
            animator.speed = 1f;
            animator.ResetTrigger(roarTriggerParam);
            animator.SetTrigger(roarTriggerParam);
        }
    }

    private void TickRoar()
    {
        if (lockedTarget == null || !IsTargetValid(lockedTarget))
        {
            lockedTarget = null;
            state = State.Patrol;
            return;
        }

        FaceTowards(lockedTarget.position);

        roarTimer -= Time.deltaTime;
        if (roarTimer <= 0f)
            state = State.Chase;
    }

    private void TickChase()
    {
        ReleaseVictimAndCamera();
        lockFacingActive = false;

        if (lockedTarget == null || !IsTargetValid(lockedTarget))
        {
            lockedTarget = null;
            state = State.Patrol;
            return;
        }

        if (!IsDetectable(lockedTarget))
        {
            lockedTarget = null;
            state = State.Patrol;
            return;
        }

        float d = HorizontalDistance(transform.position, lockedTarget.position);
        if (d <= grabStartRange)
        {
            StartGrab();
            return;
        }

        MoveTowards(lockedTarget.position, runSpeed);
    }

    private void StartGrab()
    {
        if (lockedTarget == null) { state = State.Patrol; return; }

        // 한 번만 바라보고 고정(빙글빙글 방지)
        FaceTowards(lockedTarget.position);
        lockedFacingRotation = transform.rotation;
        lockFacingActive = true;

        CaptureVictimAndStartCamera();

        if (animator != null && !string.IsNullOrEmpty(grabTriggerParam))
        {
            animator.speed = 1f;
            animator.ResetTrigger(grabTriggerParam);
            animator.SetTrigger(grabTriggerParam);
        }

        grabTimer = Mathf.Max(0.05f, grabFallbackTime);
        state = State.GrabAnim;
    }

    private void TickGrabAnim()
    {
        if (lockedTarget == null || !IsTargetValid(lockedTarget))
        {
            lockedTarget = null;
            ReleaseVictimAndCamera();
            state = State.Patrol;
            lockFacingActive = false;
            return;
        }

        if (lockFacingActive) transform.rotation = lockedFacingRotation;

        float d = HorizontalDistance(transform.position, lockedTarget.position);
        if (d > grabConfirmRange)
        {
            ReleaseVictimAndCamera();
            state = State.Chase;
            lockFacingActive = false;
            return;
        }

        bool grabEnded = false;
        if (animator != null)
        {
            var info = animator.GetCurrentAnimatorStateInfo(0);
            if (info.IsTag(grabStateTag) && info.normalizedTime >= 0.98f)
                grabEnded = true;
        }

        grabTimer -= Time.deltaTime;
        if (!grabEnded && grabTimer > 0f) return;

        TriggerAttack();
    }

    private void TriggerAttack()
    {
        if (lockedTarget == null)
        {
            ReleaseVictimAndCamera();
            state = State.Patrol;
            lockFacingActive = false;
            return;
        }

        if (animator != null && !string.IsNullOrEmpty(attackTriggerParam))
        {
            animator.speed = 1f;
            animator.ResetTrigger(attackTriggerParam);
            animator.SetTrigger(attackTriggerParam);
        }

        attackFrozen = false;
        attackHoldTimer = Mathf.Max(0.01f, attackHoldTime);
        attackStartTime = Time.time;

        if (victimLock != null) victimLock.SetCinematicZoom01(0f); // 줌은 attack에서 시작
        state = State.Attack;
    }

    private void TickAttack()
    {
        if (lockedTarget == null || !IsTargetValid(lockedTarget))
        {
            lockedTarget = null;
            ForceReleaseToPatrol();
            return;
        }

        if (lockFacingActive) transform.rotation = lockedFacingRotation;

        // 줌 진행(Attack에서만)
        if (victimLock != null && attackZoomDuration > 0.01f)
        {
            float t = Mathf.Clamp01((Time.time - attackStartTime) / attackZoomDuration);
            victimLock.SetCinematicZoom01(t);
        }

        // (1) Tag로 "Attack 마지막 프레임" 감지
        if (!attackFrozen && animator != null)
        {
            var info = animator.GetCurrentAnimatorStateInfo(0);
            if (info.IsTag(attackStateTag) && info.normalizedTime >= 0.98f)
            {
                attackFrozen = true;
                animator.speed = 0f; // 마지막 프레임 고정
            }
        }

        // (2) Tag가 안 먹으면 클립 길이로 fallback (attackClipLength 설정값 사용)
        if (!attackFrozen)
        {
            float elapsed = Time.time - attackStartTime;
            if (elapsed >= Mathf.Max(0.05f, attackClipLength))
            {
                attackFrozen = true;
                if (animator != null) animator.speed = 0f;
            }
        }

        // 강제 탈출(안 풀리는 버그 방지)
        if (Time.time - attackStartTime >= Mathf.Max(0.5f, attackMaxTotalTime))
        {
            if (debugLogs) Debug.LogWarning("[WraithAI] Attack timeout -> Force release");
            ApplyExecuteDamage();
            ForceReleaseToPatrol();
            return;
        }

        if (!attackFrozen) return;

        attackHoldTimer -= Time.deltaTime;
        if (attackHoldTimer > 0f) return;

        // Hold 끝 -> 데미지 -> 놓고 patrol
        ApplyExecuteDamage();
        ForceReleaseToPatrol();
    }

    private void ApplyExecuteDamage()
    {
        if (lockedTarget == null) return;

        // 1) 데미지(처치)
        Health th = lockedTarget.GetComponentInChildren<Health>();
        if (th != null && !th.IsDead())
            th.ApplyDamage(executeDamage);

        var mark = lockedTarget.GetComponentInChildren<WraithVengeanceMark>();
        if (mark != null)
            mark.creatureKills = 0;

        provokedTargets.Remove(lockedTarget);
    }


    private void ForceReleaseToPatrol()
    {
        if (animator != null) animator.speed = 1f;

        ReleaseVictimAndCamera();
        lockedTarget = null;
        lockFacingActive = false;
        state = State.Patrol;
    }

    private void TickDead()
    {
        if (animator != null && !string.IsNullOrEmpty(isDeadParam))
            animator.SetBool(isDeadParam, true);

        if (animator != null) animator.speed = 1f;

        ReleaseVictimAndCamera();
        lockFacingActive = false;
    }

    private void OnDeath(Health h)
    {
        state = State.Dead;
    }

    private void CaptureVictimAndStartCamera()
    {
        if (lockedTarget == null) return;

        victimLock = lockedTarget.GetComponent<WraithVictimLock>();
        if (victimLock == null) victimLock = lockedTarget.gameObject.AddComponent<WraithVictimLock>();

        Transform hold = victimHoldPoint != null ? victimHoldPoint : transform;
        Transform face = wraithFacePoint != null ? wraithFacePoint : transform;

        victimLock.Capture(hold, face);
        victimLock.SetCinematicZoom01(0f); // 고정은 즉시, 줌은 attack에서
    }

    private void ReleaseVictimAndCamera()
    {
        if (victimLock != null)
        {
            victimLock.Release();
            victimLock = null;
        }
    }

    private void ApplyGravity()
    {
        if (controller == null || !controller.enabled) return;
        if (state == State.Dead) return;

        if (controller.isGrounded && verticalVelocity < 0f)
            verticalVelocity = -2f;

        verticalVelocity += gravity * Time.deltaTime;
        controller.Move(Vector3.up * verticalVelocity * Time.deltaTime);
    }

    private void MoveTowards(Vector3 target, float speed)
    {
        if (controller == null || !controller.enabled) return;
        if (state == State.Roar || state == State.GrabAnim || state == State.Attack) return;

        Vector3 dir = target - transform.position;
        dir.y = 0f;

        float dist = dir.magnitude;
        if (dist < 0.001f) return;

        dir /= dist;

        Quaternion q = Quaternion.LookRotation(dir, Vector3.up);
        transform.rotation = Quaternion.Slerp(transform.rotation, q, turnSpeed * Time.deltaTime);

        controller.Move(dir * speed * Time.deltaTime);
    }

    private void FaceTowards(Vector3 target)
    {
        Vector3 dir = target - transform.position;
        dir.y = 0f;
        if (dir.sqrMagnitude < 0.0001f) return;

        Quaternion q = Quaternion.LookRotation(dir.normalized, Vector3.up);
        transform.rotation = Quaternion.Slerp(transform.rotation, q, turnSpeed * Time.deltaTime);
    }

    private float HorizontalDistance(Vector3 a, Vector3 b)
    {
        a.y = 0f; b.y = 0f;
        return Vector3.Distance(a, b);
    }

    private void UpdateAnimatorSpeed()
    {
        if (animator == null || string.IsNullOrEmpty(speedParam)) return;

        float dt = Time.deltaTime;
        if (dt <= 0f) return;

        Vector3 delta = transform.position - lastPos;
        delta.y = 0f;

        float raw = delta.magnitude / dt;
        if (raw < 0.15f) raw = 0f;

        smoothedSpeed = Mathf.Lerp(smoothedSpeed, raw, dt * Mathf.Max(0.1f, speedDamp));
        animator.SetFloat(speedParam, smoothedSpeed);
    }
}
