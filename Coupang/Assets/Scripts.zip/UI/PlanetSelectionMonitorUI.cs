using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// Ship monitor UI for choosing the next planet before launching.
/// - Draws 2 random planet candidates from PlanetCatalog.
/// - For each planet, draws a random DeliveryContract and shows required cargo (by CargoType) + max reward.
/// - Player selects one candidate and confirms.
/// - GameSession consumes PlanetSelectionState at launch and loads the chosen planet.
/// </summary>
public class PlanetSelectionMonitorUI : MonoBehaviour
{
    [Header("Data")]
    public PlanetCatalog planetCatalog;

    [Tooltip("Fallback contract directory if the planet entry has none.")]
    public DeliveryContractDirectory fallbackContractDirectory;

    [Tooltip("Legacy fallback pricing table (not used by the new mission-cargo display, kept for compatibility).")]
    public DeliveryPricingTable fallbackPricingTable;

    [Header("Option A UI")]
    public TMP_Text optionATitle;
    public TMP_Text optionADetails;
    public Button optionAButton;

    [Header("Option B UI")]
    public TMP_Text optionBTitle;
    public TMP_Text optionBDetails;
    public Button optionBButton;

    [Header("Controls")]
    public Button rerollButton;
    public Button confirmButton;
    public Button backButton; // same role as ESC (close)
    public TMP_Text statusText;

    [Header("Behavior")]
    [Tooltip("If true, candidates are generated when the panel is enabled (if none exist yet).")]
    public bool generateOnEnable = true;

    [Tooltip("If true, pressing ESC will close this panel.")]
    public bool closeOnEscape = true;

    private PlanetSelectionState.Offer _a;
    private PlanetSelectionState.Offer _b;

    private void OnEnable()
    {
        WireButtons();

        if (generateOnEnable)
        {
            if (!PlanetSelectionState.HasCandidates)
                GenerateCandidates();
        }

        LoadFromState();
        RefreshUI();
    }

    private void Update()
    {
        if (!closeOnEscape) return;

        // Close only when this panel is active.
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Close();
        }
    }

    private void WireButtons()
    {
        if (optionAButton != null)
        {
            optionAButton.onClick.RemoveListener(OnPickA);
            optionAButton.onClick.AddListener(OnPickA);
        }

        if (optionBButton != null)
        {
            optionBButton.onClick.RemoveListener(OnPickB);
            optionBButton.onClick.AddListener(OnPickB);
        }

        if (rerollButton != null)
        {
            rerollButton.onClick.RemoveListener(GenerateCandidates);
            rerollButton.onClick.AddListener(GenerateCandidates);
        }

        if (confirmButton != null)
        {
            confirmButton.onClick.RemoveListener(ConfirmSelection);
            confirmButton.onClick.AddListener(ConfirmSelection);
        }

        if (backButton != null)
        {
            backButton.onClick.RemoveListener(Close);
            backButton.onClick.AddListener(Close);
        }
    }

    public void Close()
    {
        // Do NOT clear state; just close the UI.
        gameObject.SetActive(false);
    }

    public void GenerateCandidates()
    {
        if (planetCatalog == null)
        {
            SetStatus("PlanetCatalog missing.");
            return;
        }

        var p1 = planetCatalog.GetRandomPlanet();
        var p2 = GetRandomPlanetDifferentFrom(p1);

        _a = BuildOffer(p1);
        _b = BuildOffer(p2);

        PlanetSelectionState.SetCandidates(_a, _b);
        PlanetSelectionState.SetSelectedIndex(0);
        PlanetSelectionState.SetConfirmed(false);

        LoadFromState();
        RefreshUI();
        SetStatus("Candidates rerolled.");
    }

    private PlanetCatalog.PlanetEntry GetRandomPlanetDifferentFrom(PlanetCatalog.PlanetEntry other)
    {
        if (planetCatalog == null)
            return null;

        PlanetCatalog.PlanetEntry p = planetCatalog.GetRandomPlanet();
        if (other == null)
            return p;

        for (int i = 0; i < 8; i++)
        {
            if (p != null && p != other)
                return p;

            p = planetCatalog.GetRandomPlanet();
        }

        // If the catalog has only one planet, this may return the same planet.
        return p;
    }

    private PlanetSelectionState.Offer BuildOffer(PlanetCatalog.PlanetEntry planet)
    {
        PlanetSelectionState.Offer offer = new PlanetSelectionState.Offer();
        offer.planet = planet;
        offer.contract = null;

        if (planet != null)
        {
            DeliveryContractDirectory dir = (planet.contractDirectory != null) ? planet.contractDirectory : fallbackContractDirectory;
            if (dir != null)
                offer.contract = dir.GetRandomContract();
        }

        return offer;
    }

    private void LoadFromState()
    {
        if (!PlanetSelectionState.HasCandidates)
            return;

        _a = PlanetSelectionState.GetCandidate(0);
        _b = PlanetSelectionState.GetCandidate(1);
    }

    private void RefreshUI()
    {
        int sel = PlanetSelectionState.GetSelectedIndex();

        // Titles
        if (optionATitle != null) optionATitle.text = BuildTitle(_a, isSelected: sel == 0);
        if (optionBTitle != null) optionBTitle.text = BuildTitle(_b, isSelected: sel == 1);

        // Details
        if (optionADetails != null) optionADetails.text = BuildOfferDetails(_a);
        if (optionBDetails != null) optionBDetails.text = BuildOfferDetails(_b);

        // Buttons
        if (optionAButton != null) optionAButton.interactable = PlanetSelectionState.HasCandidates;
        if (optionBButton != null) optionBButton.interactable = PlanetSelectionState.HasCandidates;

        if (confirmButton != null) confirmButton.interactable = PlanetSelectionState.HasCandidates;

        // Status
        if (statusText != null)
        {
            if (!PlanetSelectionState.HasCandidates)
                statusText.text = "No candidates. Press Reroll.";
            else if (!PlanetSelectionState.HasSelection)
                statusText.text = "Pick a destination.";
            else if (!PlanetSelectionState.HasConfirmed)
                statusText.text = "Confirm selection to lock in.";
            else
                statusText.text = "Destination confirmed. Pull the lever to launch.";
        }
    }

    private string BuildTitle(PlanetSelectionState.Offer offer, bool isSelected)
    {
        string planetName = (offer.planet != null) ? offer.planet.displayName : "(None)";
        string contractName = (offer.contract != null && !string.IsNullOrEmpty(offer.contract.displayName))
            ? offer.contract.displayName
            : "(No Contract)";

        return isSelected ? $"> {planetName} - {contractName}" : $"{planetName} - {contractName}";
    }

    private string BuildOfferDetails(PlanetSelectionState.Offer offer)
    {
        if (offer.planet == null)
            return "Planet: (None)";

        StringBuilder sb = new StringBuilder();

        sb.AppendLine($"Scene: {offer.planet.gameplaySceneName}");

        if (offer.contract == null)
        {
            sb.AppendLine("Contract: (None)");
            return sb.ToString();
        }

        // Cargo requirements by type
        Dictionary<CargoType, int> typeCounts = new Dictionary<CargoType, int>();
        int maxReward = offer.contract.ComputeMaxReward();

        if (offer.contract.requiredItems == null || offer.contract.requiredItems.Length == 0)
        {
            sb.AppendLine("Cargo: (not configured)");
        }
        else
        {
            for (int i = 0; i < offer.contract.requiredItems.Length; i++)
            {
                var r = offer.contract.requiredItems[i];
                if (r == null || r.item == null) continue;

                CargoType type = r.item.cargoType;
                int qty = Mathf.Max(1, r.requiredQty);

                if (typeCounts.ContainsKey(type))
                    typeCounts[type] += qty;
                else
                    typeCounts.Add(type, qty);
            }

            if (typeCounts.Count == 0)
            {
                sb.AppendLine("Cargo: (not configured)");
            }
            else
            {
                sb.AppendLine("Cargo:");
                foreach (var kv in typeCounts)
                {
                    if (kv.Value <= 0) continue;
                    sb.AppendLine($"- {kv.Key} x{kv.Value}");
                }
            }
        }

        sb.AppendLine($"Max reward: {maxReward}");

        return sb.ToString();
    }

    private void OnPickA()
    {
        PlanetSelectionState.SetSelectedIndex(0);
        PlanetSelectionState.SetConfirmed(false);
        RefreshUI();
    }

    private void OnPickB()
    {
        PlanetSelectionState.SetSelectedIndex(1);
        PlanetSelectionState.SetConfirmed(false);
        RefreshUI();
    }

    private void ConfirmSelection()
    {
        PlanetSelectionState.SetConfirmed(true);
        RefreshUI();
    }

    private void SetStatus(string msg)
    {
        if (statusText != null)
            statusText.text = msg;
    }
}
