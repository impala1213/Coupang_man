// Assets/Scripts/UI/PlayerEnergyUI.cs
using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// Player energy HUD.
/// - Binds to an Energy component (auto by PlayerController).
/// - Updates a Slider and optional text.
/// - Shows current consumption as lightning icons under the bar.
///   (Icons count is driven by Energy.currentDrainUnits.)
/// </summary>
[DisallowMultipleComponent]
public class PlayerEnergyUI : MonoBehaviour
{
    [Header("Binding")]
    public PlayerController player;
    public Energy energy;
    public bool autoBind = true;

    [Header("UI")]
    public Slider energySlider;
    public TextMeshProUGUI energyText;

    [Header("Consumption Icons")]
    [Tooltip("If assigned, shows lightning icons by repeating this character.")]
    public TextMeshProUGUI boltsText;

    [Tooltip("Character used in boltsText. Default is '⚡'.")]
    public string boltChar = "⚡";

    [Tooltip("Clamp the displayed bolts count.")]
    [Min(1)] public int maxBolts = 10;

    [Header("Behavior")]
    public bool useNormalizedSlider = true;

    private int _lastHash = int.MinValue;

    void Awake()
    {
        if (autoBind)
            ResolveReferences();

        ResolveUIReferences();
        Subscribe();
        ForceRefresh();
    }

    void OnEnable()
    {
        if (autoBind)
            ResolveReferences();

        Subscribe();
        ForceRefresh();
    }

    void OnDisable()
    {
        Unsubscribe();
    }

    void OnDestroy()
    {
        Unsubscribe();
    }

    void Update()
    {
        int h = ComputeHash();
        if (h != _lastHash)
        {
            _lastHash = h;
            Refresh();
        }
    }

    public void ForceRefresh()
    {
        _lastHash = int.MinValue;
        Refresh();
    }

    private void ResolveReferences()
    {
        if (!player)
            player = FindFirstObjectByType<PlayerController>();

        if (!energy && player)
            energy = player.GetComponent<Energy>();
    }

    private void ResolveUIReferences()
    {
        if (!energySlider)
            energySlider = GetComponentInChildren<Slider>(true);

        if (!energyText)
        {
            // If there are multiple TMP texts (e.g. value text + bolts text),
            // avoid accidentally binding the boltsText as the main value text.
            var tmps = GetComponentsInChildren<TextMeshProUGUI>(true);
            if (tmps != null)
            {
                for (int i = 0; i < tmps.Length; i++)
                {
                    if (!tmps[i]) continue;
                    if (boltsText && tmps[i] == boltsText) continue;
                    energyText = tmps[i];
                    break;
                }
            }
        }
    }

    private void Subscribe()
    {
        if (!energy) return;

        energy.OnChanged -= OnEnergyChanged;
        energy.OnDepleted -= OnEnergyDepleted;
        energy.OnDrainUnitsChanged -= OnDrainUnitsChanged;

        energy.OnChanged += OnEnergyChanged;
        energy.OnDepleted += OnEnergyDepleted;
        energy.OnDrainUnitsChanged += OnDrainUnitsChanged;
    }

    private void Unsubscribe()
    {
        if (!energy) return;

        energy.OnChanged -= OnEnergyChanged;
        energy.OnDepleted -= OnEnergyDepleted;
        energy.OnDrainUnitsChanged -= OnDrainUnitsChanged;
    }

    private void OnEnergyChanged(Energy e, float value)
    {
        ForceRefresh();
    }

    private void OnEnergyDepleted(Energy e)
    {
        ForceRefresh();
    }

    private void OnDrainUnitsChanged(Energy e, int units)
    {
        ForceRefresh();
    }

    private void Refresh()
    {
        if (!energy)
        {
            if (energySlider)
            {
                energySlider.minValue = 0f;
                energySlider.maxValue = 1f;
                energySlider.value = 0f;
            }

            if (energyText) energyText.text = "";
            SetBolts(0);
            return;
        }

        float max = Mathf.Max(0.01f, energy.maxEnergy);
        float cur = Mathf.Clamp(energy.currentEnergy, 0f, max);

        if (energySlider)
        {
            if (useNormalizedSlider)
            {
                energySlider.minValue = 0f;
                energySlider.maxValue = 1f;
                energySlider.value = Mathf.Clamp01(cur / max);
            }
            else
            {
                energySlider.minValue = 0f;
                energySlider.maxValue = max;
                energySlider.value = cur;
            }
        }

        if (energyText)
            energyText.text = $"{Mathf.CeilToInt(cur)} / {Mathf.CeilToInt(max)}";

        SetBolts(energy.currentDrainUnits);
    }

    private void SetBolts(int units)
    {
        if (!boltsText) return;

        int n = Mathf.Clamp(units, 0, Mathf.Max(1, maxBolts));
        if (n <= 0)
        {
            boltsText.text = "";
            return;
        }

        // Build a small string like "⚡⚡⚡".
        // maxBolts is small, so simple concatenation is fine.
        string s = "";
        for (int i = 0; i < n; i++)
            s += boltChar;

        boltsText.text = s;
    }

    private int ComputeHash()
    {
        if (!energy) return 0x13579BDF;

        unchecked
        {
            // Quantize energy so we don't refresh every frame with tiny float changes.
            int max = Mathf.Max(1, Mathf.CeilToInt(energy.maxEnergy * 100f));
            int cur = Mathf.Clamp(Mathf.CeilToInt(energy.currentEnergy * 100f), 0, max);
            int units = Mathf.Max(0, energy.currentDrainUnits);
            int dep = energy.IsDepleted() ? 1 : 0;

            int h = 17;
            h = h * 31 + max;
            h = h * 31 + cur;
            h = h * 31 + units;
            h = h * 31 + dep;
            return h;
        }
    }
}
