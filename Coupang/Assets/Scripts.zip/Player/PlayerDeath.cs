// Assets/Scripts/Player/PlayerDeathDropper.cs
using UnityEngine;

[RequireComponent(typeof(Health))]
public class PlayerDeath : MonoBehaviour
{
    [Header("References")]
    public InventorySystem inventory;      // �ɼ�, ��� ������ �ڵ� ã��
    public CarrierController carrier;      // �ɼ�, ��� ������ �ڵ� ã��
    public Transform dropOrigin;           // �ɼ�, ��� ������ this.transform ���

    private Health health;

    private void Awake()
    {
        health = GetComponent<Health>();

        if (inventory == null)
            inventory = GetComponent<InventorySystem>();

        if (carrier == null)
            carrier = GetComponent<CarrierController>();

        if (dropOrigin == null)
            dropOrigin = transform;

        if (health != null)
        {
            health.OnDeath += OnPlayerDeath;
        }
    }

    private void OnDestroy()
    {
        if (health != null)
        {
            health.OnDeath -= OnPlayerDeath;
        }
    }

    private void OnPlayerDeath(Health h)
    {
        Transform origin = dropOrigin != null ? dropOrigin : transform;
        Vector3 forward = transform.forward;

        // 1) ĳ��� ����� �� ���� ���
        if (carrier != null && carrier.HasAnyMounted())
        {
            carrier.SpillAllOnCarrierDrop(origin.position, forward);
        }

        // 2) �κ��丮 �� ���� ������ ���
        if (inventory != null)
        {
            DropAllInventory(inventory, origin, forward);
        }
    }

    private void DropAllInventory(InventorySystem inv, Transform origin, Vector3 forward)
    {
        // InventorySystem ���� API�� ���:
        // slotCount, SetActiveIndex, DropActiveItem
        int slots = inv.slotCount;

        for (int i = 0; i < slots; i++)
        {
            inv.SetActiveIndex(i);
            inv.DropActiveItem(origin, forward);
        }
    }
}
