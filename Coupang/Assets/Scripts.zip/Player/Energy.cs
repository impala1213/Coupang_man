using System;
using UnityEngine;

/// <summary>
/// Player energy (time limit) resource.
/// - Drains every frame by (drainUnits * drainPerUnitPerSecond).
/// - When it reaches 0, it becomes depleted and can be used to lock player input.
/// - Supports future extensions such as energy transfer (AddEnergy).
/// </summary>
[DisallowMultipleComponent]
public class Energy : MonoBehaviour
{
    [Header("Energy")]
    [Min(0.01f)] public float maxEnergy = 120f;
    public float currentEnergy;

    [Header("Drain")]
    [Tooltip("Energy drained per second for 1 drain unit.")]
    [Min(0f)] public float drainPerUnitPerSecond = 1f;

    [Tooltip("Current drain units used for draining. Set by the controller/owner.")]
    [Min(0)] public int currentDrainUnits = 1;

    public event Action<Energy> OnDepleted;
    public event Action<Energy, float> OnChanged;
    public event Action<Energy, int> OnDrainUnitsChanged;

    private bool _isDepleted;

    void Awake()
    {
        currentEnergy = maxEnergy;
        _isDepleted = false;
        currentDrainUnits = Mathf.Max(0, currentDrainUnits);
    }

    void Update()
    {
        if (_isDepleted) return;
        if (drainPerUnitPerSecond <= 0f) return;
        if (currentDrainUnits <= 0) return;

        float drain = currentDrainUnits * drainPerUnitPerSecond * Time.deltaTime;
        if (drain <= 0f) return;

        currentEnergy -= drain;
        if (currentEnergy <= 0f)
        {
            currentEnergy = 0f;
            _isDepleted = true;
            OnChanged?.Invoke(this, currentEnergy);
            OnDepleted?.Invoke(this);
            return;
        }

        OnChanged?.Invoke(this, currentEnergy);
    }

    public void SetDrainUnits(int units)
    {
        units = Mathf.Max(0, units);
        if (units == currentDrainUnits) return;

        currentDrainUnits = units;
        OnDrainUnitsChanged?.Invoke(this, currentDrainUnits);
    }

    public void AddEnergy(float amount)
    {
        if (amount <= 0f) return;

        float prev = currentEnergy;
        currentEnergy = Mathf.Min(maxEnergy, currentEnergy + amount);

        // If energy is restored from 0, clear depleted state.
        if (_isDepleted && currentEnergy > 0f)
            _isDepleted = false;

        if (!Mathf.Approximately(prev, currentEnergy))
            OnChanged?.Invoke(this, currentEnergy);
    }

    public void SetMaxEnergy(float newMax, bool refill = false)
    {
        newMax = Mathf.Max(0.01f, newMax);
        maxEnergy = newMax;
        if (refill) currentEnergy = maxEnergy;
        currentEnergy = Mathf.Clamp(currentEnergy, 0f, maxEnergy);

        if (_isDepleted && currentEnergy > 0f)
            _isDepleted = false;

        OnChanged?.Invoke(this, currentEnergy);
    }

    public bool IsDepleted()
    {
        return _isDepleted;
    }
}
