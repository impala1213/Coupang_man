using UnityEngine;

/// <summary>
/// Ship monitor/terminal interactable.
/// Uses the existing PlayerInteractableBase pipeline (ray focus + E press).
/// 
/// - Shows a control hint via InteractionLock.TerminalHasFocus.
/// - Opens/closes a modal terminal UI when used.
/// </summary>
public class MonitorTerminalInteractable : PlayerInteractableBase
{
    [Header("Terminal")]
    public MonitorTerminalUIController uiController;

    public override void OnFocusEnter(PlayerController player)
    {
        InteractionLock.SetTerminalFocus(true);
    }

    public override void OnFocusExit(PlayerController player)
    {
        InteractionLock.SetTerminalFocus(false);
    }

    public override void OnUsePressed(PlayerController player)
    {
        if (uiController == null)
        {
            Debug.LogWarning("MonitorTerminalInteractable: uiController is not assigned.");
            return;
        }

        uiController.Toggle();
    }
}
