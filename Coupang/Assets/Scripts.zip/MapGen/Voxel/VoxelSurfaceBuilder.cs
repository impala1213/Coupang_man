using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Static helper that analyzes a voxel field and builds surface classification
/// (floor / wall / ceiling + region flags) into a VoxelSurfaceData component.
///
/// Typical use:
///   var surfaceData = VoxelSurfaceBuilder.BuildSurfaceData(
///       chunkGO,
///       chunk.voxels,
///       voxelSize,
///       worldBottomY,
///       roomMask: roomMask,
///       corridorMask: corridorMask,
///       maxWorldY: caveRegionMaxWorldY
///   );
///
/// ���� �ٸ� ��ũ��Ʈ���� surfaceData.cells �� �����ؼ�
/// - �� �ٴڿ��� ���� ����
/// - ��� õ�忡�� ������ ����
/// - ���� ������ �̳� ����
/// ���� ������ ������ �� �ִ�.
/// </summary>
public static class VoxelSurfaceBuilder
{
    /// <summary>
    /// Build and attach VoxelSurfaceData to the given chunk GameObject.
    /// </summary>
    /// <param name="owner">
    /// GameObject that represents the voxel chunk (same one that has VoxelChunk).
    /// </param>
    /// <param name="voxels">
    /// VoxelType 3D array (Air / Ground / Underground / Cave ...).
    /// </param>
    /// <param name="voxelSize">
    /// World size of one voxel edge.
    /// </param>
    /// <param name="worldBottomY">
    /// World Y at voxel y=0.
    /// </param>
    /// <param name="roomMask">
    /// Optional mask indicating which air cells belong to "room" region.
    /// If null, no Room region flags are set.
    /// </param>
    /// <param name="corridorMask">
    /// Optional mask indicating which air cells belong to "corridor" region.
    /// If null, no Corridor region flags are set.
    /// </param>
    /// <param name="maxWorldY">
    /// Optional max world Y for classification. Any air cells whose center Y
    /// is above this will be ignored (useful to only classify underground part).
    /// Pass null to classify all heights.
    /// </param>
    public static VoxelSurfaceData BuildSurfaceData(
        GameObject owner,
        VoxelType[,,] voxels,
        float voxelSize,
        float worldBottomY,
        bool[,,] roomMask = null,
        bool[,,] corridorMask = null,
        float? maxWorldY = null)
    {
        if (owner == null || voxels == null)
        {
            Debug.LogError("VoxelSurfaceBuilder.BuildSurfaceData: owner or voxels is null.");
            return null;
        }

        int sizeX = voxels.GetLength(0);
        int sizeY = voxels.GetLength(1);
        int sizeZ = voxels.GetLength(2);

        // Get or add VoxelSurfaceData component on this chunk
        VoxelSurfaceData data = owner.GetComponent<VoxelSurfaceData>();
        if (data == null)
        {
            data = owner.AddComponent<VoxelSurfaceData>();
        }
        data.Initialize(sizeX, sizeY, sizeZ, voxelSize, worldBottomY);

        VoxelSurfaceFlags[,,] flags = data.flags;

        // Safety: if masks are given, they must match dimensions
        if (roomMask != null &&
            (roomMask.GetLength(0) != sizeX ||
             roomMask.GetLength(1) != sizeY ||
             roomMask.GetLength(2) != sizeZ))
        {
            Debug.LogWarning("VoxelSurfaceBuilder: roomMask dimension mismatch. Ignoring roomMask.");
            roomMask = null;
        }

        if (corridorMask != null &&
            (corridorMask.GetLength(0) != sizeX ||
             corridorMask.GetLength(1) != sizeY ||
             corridorMask.GetLength(2) != sizeZ))
        {
            Debug.LogWarning("VoxelSurfaceBuilder: corridorMask dimension mismatch. Ignoring corridorMask.");
            corridorMask = null;
        }

        float maxYLimit = float.MaxValue;
        if (maxWorldY.HasValue)
            maxYLimit = maxWorldY.Value + voxelSize * 0.5f;

        // Compact list of surface cells (spawn candidates)
        List<VoxelSurfaceData.SurfaceCell> cellList = new List<VoxelSurfaceData.SurfaceCell>();

        // Helper to treat any non-Air as solid
        bool IsSolid(VoxelType t) => t != VoxelType.Air;

        Transform tOwner = owner.transform;

        // Classification loop:
        // - Only look at Air cells (caves, rooms, corridors, etc.)
        // - For each Air cell, check solid below/above/sides to tag Floor/Wall/Ceiling
        // - Also set Region flags (Room / Corridor / GenericCave)
        for (int z = 0; z < sizeZ; z++)
        {
            for (int x = 0; x < sizeX; x++)
            {
                // y=0, y=sizeY-1 �� ���Ʒ� �̿� üũ���� out-of-bounds ���ϱ� ���� ����
                for (int y = 1; y < sizeY - 1; y++)
                {
                    if (voxels[x, y, z] == VoxelType.Air == false)
                        continue;

                    float worldYCenter = worldBottomY + (y + 0.5f) * voxelSize;
                    if (worldYCenter > maxYLimit)
                        continue;

                    // ���������� Region classification ����������
                    VoxelRegionFlags region = VoxelRegionFlags.None;

                    bool isRoom = (roomMask != null && roomMask[x, y, z]);
                    bool isCorridor = (corridorMask != null && corridorMask[x, y, z]);

                    if (isRoom)
                    {
                        region |= VoxelRegionFlags.Room;
                    }
                    if (isCorridor)
                    {
                        region |= VoxelRegionFlags.Corridor;
                    }

                    // ��/��ΰ� �ƴ� ���� Air ���� GenericCave�� ���
                    if (region == VoxelRegionFlags.None)
                    {
                        // �� ������ ���� ����(caveRegionMaxWorldY ����)�� ������� ���̹Ƿ�
                        // ������ Exterior ���� ���� GenericCave �� ���´�.
                        region |= VoxelRegionFlags.GenericCave;
                    }

                    // ���������� Geometric orientation (Floor / Wall / Ceiling) ����������
                    VoxelSurfaceFlags f = VoxelSurfaceFlags.None;

                    bool hasFloor = IsSolid(voxels[x, y - 1, z]);
                    bool hasCeiling = IsSolid(voxels[x, y + 1, z]);

                    if (hasFloor)
                        f |= VoxelSurfaceFlags.Floor;

                    if (hasCeiling)
                        f |= VoxelSurfaceFlags.Ceiling;

                    // Horizontal walls
                    bool hasWall = false;
                    if (x > 0 && IsSolid(voxels[x - 1, y, z])) hasWall = true;
                    else if (x < sizeX - 1 && IsSolid(voxels[x + 1, y, z])) hasWall = true;
                    else if (z > 0 && IsSolid(voxels[x, y, z - 1])) hasWall = true;
                    else if (z < sizeZ - 1 && IsSolid(voxels[x, y, z + 1])) hasWall = true;

                    if (hasWall)
                        f |= VoxelSurfaceFlags.Wall;

                    if (f == VoxelSurfaceFlags.None)
                    {
                        // �� air cell �ֺ��� solid �� ���
                        // �ٴ�/��/õ�� ǥ������ ���� ���� �� ���� �ĺ� ����
                        continue;
                    }

                    // 3D flags �迭�� ��� (���� ������)
                    flags[x, y, z] = f;

                    // ���������� SurfaceCell ���� (worldPosition + normal ��) ����������
                    VoxelSurfaceData.SurfaceCell cell = new VoxelSurfaceData.SurfaceCell();
                    cell.x = x;
                    cell.y = y;
                    cell.z = z;
                    cell.surfaceFlags = f;
                    cell.regionFlags = region;

                    // ���� ���� ��ǥ
                    Vector3 localCenter = new Vector3(
                        (x + 0.5f) * voxelSize,
                        (y + 0.5f) * voxelSize,
                        (z + 0.5f) * voxelSize
                    );

                    Vector3 localPos = localCenter;   // ���� ��ġ
                    Vector3 localNormal = Vector3.zero; // ǥ�� ����

                    // Floor / Ceiling
                    if (hasFloor)
                    {
                        localNormal += Vector3.up;
                        // �ٴ� ������ �Ʒ��� �� voxel
                        localPos = localCenter - Vector3.up * (0.5f * voxelSize);
                    }

                    if (hasCeiling)
                    {
                        localNormal += Vector3.down;

                        // ���� Floor �� ���� Ceiling�� �ִ� ���, ������ õ�� ������
                        if (!hasFloor)
                        {
                            localPos = localCenter + Vector3.up * (0.5f * voxelSize);
                        }
                    }

                    // Walls: �ֺ� solid ������ ������� ���� ����
                    if (hasWall)
                    {
                        if (x > 0 && IsSolid(voxels[x - 1, y, z]))
                            localNormal += Vector3.right; // solid ���� �� normal +X

                        if (x < sizeX - 1 && IsSolid(voxels[x + 1, y, z]))
                            localNormal += Vector3.left;  // solid ������ �� normal -X

                        if (z > 0 && IsSolid(voxels[x, y, z - 1]))
                            localNormal += Vector3.forward; // solid �� �� normal +Z

                        if (z < sizeZ - 1 && IsSolid(voxels[x, y, z + 1]))
                            localNormal += Vector3.back;    // solid �� �� normal -Z

                        // ���� Floor/Ceiling�� ���� ���� ���� �ִ� ���,
                        // �� ������ solid-���� �������� �Ű��ش�.
                        if (!hasFloor && !hasCeiling)
                        {
                            if (localNormal.sqrMagnitude > 1e-6f)
                            {
                                localNormal.Normalize();
                                // solid��air ������ normal �̹Ƿ�,
                                // ������ �߽ɿ��� -normal * halfVoxel ��ŭ �̵��� ��ġ.
                                localPos = localCenter - localNormal * (0.5f * voxelSize);
                            }
                        }
                    }

                    // localNormal �� �������̸� �⺻ up ����
                    if (localNormal.sqrMagnitude < 1e-6f)
                    {
                        localNormal = Vector3.up;
                    }
                    else
                    {
                        localNormal.Normalize();
                    }

                    // ���� �������� ��ȯ
                    cell.worldPosition = tOwner.TransformPoint(localPos);
                    cell.normal = tOwner.TransformDirection(localNormal).normalized;

                    cellList.Add(cell);
                }
            }
        }

        // SurfaceCell ����Ʈ�� �����Ϳ� ����
        data.SetSurfaceCells(cellList);

        return data;
    }
}
