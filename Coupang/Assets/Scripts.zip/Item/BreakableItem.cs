using UnityEngine;



public class BreakableItem : MonoBehaviour
{
    public ItemDefinition definition; // breakable=true, �Ӱ谪/���� ������ ����


    void OnCollisionEnter(Collision c)
    {
        if (definition == null || !definition.breakable) return;
        float impulse = c.relativeVelocity.magnitude * (GetComponent<Rigidbody>() ? GetComponent<Rigidbody>().mass : 1f);
        if (impulse >= definition.breakImpulseThreshold)
        {
            Break();
        }
    }


    void Break()
    {
        if (definition.brokenPrefab)
        {
            Instantiate(definition.brokenPrefab, transform.position, transform.rotation);
            Destroy(gameObject);
        }
        else
        {
            // ������ ��Ȱ��ȭ�� ��ü
            gameObject.SetActive(false);
        }
    }
}